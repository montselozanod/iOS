//
//  AppDelegate.h
//  DivisasMultiples
//
//  Created by Maria Montserrat Lozano on 03/02/14.
//  Copyright (c) 2014 ITESM. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
