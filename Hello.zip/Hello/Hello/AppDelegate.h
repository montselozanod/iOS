//
//  AppDelegate.h
//  Hello
//
//  Created by Maria Montserrat Lozano on 20/01/14.
//  Copyright (c) 2014 ITESM. All rights reserved.
//
//interfase
#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
